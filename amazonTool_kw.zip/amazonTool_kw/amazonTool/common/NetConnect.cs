using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.IO;

namespace amazonTool.common
{
    class NetConnect
    {
        String proxyServer = "";
        String usrid = "";
        String password = "";
        private WebResponse response = null;
        public NetConnect()
        {
            this.proxyServer = null;
            this.usrid = null;
            this.password = null;
        }
        public NetConnect(String proxyServer)
        {
            this.proxyServer = proxyServer;
            this.usrid = null;
            this.password = null;
        }

        public NetConnect(String proxyServer, String usrid, String password)
        {
            this.proxyServer = proxyServer;
            this.usrid = usrid;
            this.password = password;
        }

        public Stream getConnection(String url, bool hasHeader)
        {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            if (proxyServer != null)
            {
                WebProxy proxy = new WebProxy(proxyServer);
                if (usrid != null)
                {
                    proxy.Credentials = new NetworkCredential(usrid, password);
                }

                request.Proxy = proxy;
            }
            if (hasHeader)
            {
                request.UserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 6_0 like Mac OS X) AppleWebKit/536.26 (KHTML, like Gecko) Version/6.0 Mobile/10A403 Safari/8536.25";
                //request.Headers.Set(HttpRequestHeader.UserAgent, "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1612.2 Safari/537.36");
            }
            WebResponse response = request.GetResponse();
            //Console.WriteLine("\nThe HttpHeaders are \n\n\tName\t\tValue\n{0}", request.Headers);
            Stream stream = response.GetResponseStream();
            return stream;
        }
        public void closeConnection()
        {
            if (response != null)
            {
                response.Close();
            }
        }
    }
}
