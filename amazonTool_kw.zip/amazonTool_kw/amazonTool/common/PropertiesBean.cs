using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace amazonTool.common
{
    class PropertiesBean
    {
        private string accessKey;
        private string secretKey;
        private string amazonHost;
        private string associateTag;
        private string proxyServer;
        private string proxyUser;
        private string proxyPwd;
        private bool isChanged;
        private int service;
        private string siteURL;
        private string marketplaceId;
        private System.Data.DataTable shppingDataTable;
        private char[] shipChecked;

        // �����̎擾�E�ύX�p�̃v���p�e�B
        // �����̎擾�E�ύX�p�̃v���p�e�B
        public char[] ShipChecked
        {
            set { this.shipChecked = value; }
            get { return this.shipChecked; }
        }
        public DataTable ShppingDataTable
        {
            set { this.shppingDataTable = value; }
            get { return this.shppingDataTable; }
        }

        public string AccessKey
        {
            set { this.accessKey = value; }
            get { return this.accessKey; }
        }
        public string AssociateTag
        {
            set { this.associateTag = value; }
            get { return this.associateTag; }
        }
        public string SecretKey
        {
            set { this.secretKey = value; }
            get { return this.secretKey; }
        }
        public string AmazonHost
        {
            set { this.amazonHost = value; }
            get { return this.amazonHost; }
        }
        public string ProxyServer
        {
            set { this.proxyServer = value; }
            get { return this.proxyServer; }
        }
        public string ProxyUser
        {
            set { this.proxyUser = value; }
            get { return this.proxyUser; }
        }
        public string ProxyPwd
        {
            set { this.proxyPwd = value; }
            get { return this.proxyPwd; }
        }
        public bool IsChanged
        {
            set { this.isChanged = value; }
            get { return this.isChanged; }
        }
        public int Service
        {
            set { this.service = value; }
            get { return this.service; }
        }
        public string SiteURL
        {
            set { this.siteURL = value; }
            get { return this.siteURL; }
        }
        public string MarketplaceId
        {
            set { this.marketplaceId = value; }
            get { return this.marketplaceId; }
        }
    }
}
