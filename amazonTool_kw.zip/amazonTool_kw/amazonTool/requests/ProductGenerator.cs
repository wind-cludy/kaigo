using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using MarketplaceWebServiceProducts;
using System.Data;
using MarketplaceWebServiceProducts.Mock;
using System.Windows.Forms;
using amazonTool.common;
using System.Xml.Linq;
using System.Collections;
using MarketplaceWebServiceProducts.Model;

namespace amazonTool.requests
{
    class ProductGenerator
    {

        PropertiesBean bean;
        public ProductGenerator(PropertiesBean bean)
        {
            this.bean = bean;
        }
        public void getGetKeyWordResponse(string key,string category, List<Hashtable> listResults)
        {
            MarketplaceWebServiceProductsConfig config = new MarketplaceWebServiceProductsConfig();
            config.ServiceURL = bean.SiteURL + "/Products/2011-10-01";
            makeConfig(bean, config);
            MarketplaceWebServiceProductsClient service = new MarketplaceWebServiceProductsClient(
                            "nanoappli.com_sample", "1.0.0.0", bean.AccessKey, bean.SecretKey, config);
            ListMatchingProductsRequest request = new ListMatchingProductsRequest();
            request.SellerId = bean.AssociateTag;
            request.MarketplaceId = bean.MarketplaceId;
            request.Query = key;
            if (category != null && category.Length > 0)
            {
                request.QueryContextId = category;
            }

            ListMatchingProductsResponse response;
            response = service.ListMatchingProducts(request);

            MarketplaceWebServiceProducts.Model.ListMatchingProductsResult result = response.ListMatchingProductsResult;
            if (result.IsSetProducts())
            {
              ProductList productList =  result.Products;
                Hashtable ht = null;
                List<Product> listProduct = productList.Product;
                foreach (Product product in listProduct)
                {
                    ht = new Hashtable();

                    //ht[Const.GRIDVIEW_TITLE_NO] = i.ToString();
                    // datas[1] = resultList[i - 1].ASIN;      Hashtable  ht = new Hashtable();
                    listResults.Add(ht);

                    //count++;
                   
                        
                        if (product.IsSetIdentifiers())
                        {
                            IdentifierType identifiers = product.Identifiers;
                            if (identifiers.IsSetMarketplaceASIN())
                            {
                                ASINIdentifier asinI = identifiers.MarketplaceASIN;
                                if (asinI.IsSetASIN())
                                {
                                    string asinCd = asinI.ASIN;
                                    ht[Const.GRIDVIEW_TITLE_ASIN] = asinCd;
                                }
                            }
                        }
                        if (product.IsSetAttributeSets())
                        {
                            AttributeSetList attributeSets = product.AttributeSets;

                            if (attributeSets.IsSetAny())

                                foreach (Object attribute in attributeSets.Any)
                                {
                                    string xml = MarketplaceWebServiceProducts.Model.ProductsUtil.FormatXml((System.Xml.XmlElement)attribute);
                                    XElement element = XElement.Parse(xml);

                                    XNamespace ns2 =
                                        "http://mws.amazonservices.com/schema/Products/2011-10-01/default.xsd";
                                    XElement titleElement = element.Element(ns2 + "Title");
                                    if (titleElement != null)
                                    {
                                        ht[Const.GRIDVIEW_TITLE_TITLE] = titleElement.Value;
                                    }
                                    else
                                    {
                                        ht[Const.GRIDVIEW_TITLE_TITLE] = "";
                                    }
                                    XElement productGroupElement = element.Element(ns2 + "ProductGroup");
                                    if (productGroupElement != null)
                                    {
                                        ht[Const.GRIDVIEW_GROUP_NAME] = productGroupElement.Value;
                                    }
                                    else
                                    {
                                        ht[Const.GRIDVIEW_GROUP_NAME] = "";
                                    }
                                    XElement productTypeNameElement = element.Element(ns2 + "ProductTypeName");
                                    if (productTypeNameElement != null)
                                    {
                                        ht[Const.GRIDVIEW_TYPE_NAME] = productTypeNameElement.Value;
                                    }
                                    else
                                    {
                                        ht[Const.GRIDVIEW_TYPE_NAME] = "";
                                    }
                                    XElement manufacturerElement = element.Element(ns2 + "Manufacturer");
                                    if (manufacturerElement != null)
                                    {
                                        ht[Const.GRIDVIEW_Manufacturer] = manufacturerElement.Value;
                                    }
                                    else
                                    {
                                        ht[Const.GRIDVIEW_Manufacturer] = "";
                                    }
                                    XElement brandElement = element.Element(ns2 + "Brand");
                                    if (brandElement != null)
                                    {
                                        ht[Const.GRIDVIEW_BRAND] = brandElement.Value;
                                    }
                                    else
                                    {
                                        ht[Const.GRIDVIEW_BRAND] = "";
                                    }
                                    IEnumerable<XElement> elements = element.Elements(ns2 + "Feature");
                                    if (elements != null)
                                    {
                                        string desplay = "";
                                        foreach (XElement feature in element.Elements(ns2 + "Feature"))
                                        {
                                            desplay += feature.Value;
                                            desplay += "\n";
                                        }
                                        ht[Const.GRIDVIEW_TITLE_DESCRIPE] = desplay;
                                    }
                                    else
                                    {
                                        ht[Const.GRIDVIEW_TITLE_DESCRIPE] = "";
                                    }

                                }

                        }
                    

                }
            }
        }
        public void getGetCompetitivePricingResponse(string asinCode, List<Hashtable> listResults)
        {
            MarketplaceWebServiceProductsConfig config = new MarketplaceWebServiceProductsConfig();
            config.ServiceURL = bean.SiteURL + "/Products/2011-10-01";
            makeConfig(bean, config);
            MarketplaceWebServiceProductsClient service = new MarketplaceWebServiceProductsClient(
                            "nanoappli.com_sample", "1.0.0.0", bean.AccessKey, bean.SecretKey, config);
            GetCompetitivePricingForASINRequest request = new GetCompetitivePricingForASINRequest();
            ASINListType asinList = new ASINListType();
            asinList.ASIN = new List<string>();
            string[] inputAsinCodes = asinCode.Split(new Char[] { ',' });
            for (int i = 0; i < inputAsinCodes.Length; i++)
            {
                asinList.ASIN.Add(inputAsinCodes[i]);
            }
            int count = 0;
            request.ASINList = asinList;
            request.SellerId = bean.AssociateTag;
            request.MarketplaceId = bean.MarketplaceId;
            GetCompetitivePricingForASINResponse response = null;
            //try
            //{
            response = service.GetCompetitivePricingForASIN(request);
            List<GetCompetitivePricingForASINResult> lst = response.GetCompetitivePricingForASINResult;
            Hashtable ht = null;

            foreach (GetCompetitivePricingForASINResult rst in lst)
            {


                ht = listResults[count];
                count++;
                if (rst.IsSetProduct())
                {
                    Product product = rst.Product;
                    if (product.IsSetCompetitivePricing())
                    {
                        CompetitivePricingType competitivePricing = product.CompetitivePricing;
                        if (competitivePricing.IsSetNumberOfOfferListings())
                        {
                            NumberOfOfferListingsList numberOfOfferListingsList = competitivePricing.NumberOfOfferListings;

                            if (numberOfOfferListingsList.IsSetOfferListingCount())
                            {
                                List<OfferListingCountType> offerListingCounts = numberOfOfferListingsList.OfferListingCount;
                                foreach (OfferListingCountType offerListingCount in offerListingCounts)
                                    if (offerListingCount.condition != null && offerListingCount.condition.Equals("New"))
                                    {
                                        ht[Const.GRIDVIEW_TITLE_SUM] = offerListingCount.Value.ToString();
                                        break;
                                    }
                            }

                        }
                    }
                }

            }
            // }
            // catch (MarketplaceWebServiceProductsException ex)
            // {
            //     Console.WriteLine("Caught Exception: " + ex.Message);
            //     Console.WriteLine("Response Status Code: " + ex.StatusCode);
            //    Console.WriteLine("Error Code: " + ex.ErrorCode);
            //   Console.WriteLine("Error Type: " + ex.ErrorType);
            //    Console.WriteLine("Request ID: " + ex.RequestId);
            //  Console.WriteLine("XML: " + ex.XML);
            //   Console.WriteLine("ResponseHeaderMetadata: " + ex.ResponseHeaderMetadata);
            // }

        }
        public void getLowPriceResponse(string asinCode, List<Hashtable> listResults)
        {

            MarketplaceWebServiceProductsConfig config = new MarketplaceWebServiceProductsConfig();
            config.ServiceURL = bean.SiteURL + "/Products/2011-10-01";
            makeConfig(bean, config);
            MarketplaceWebServiceProductsClient service = new MarketplaceWebServiceProductsClient(
                            "nanoappli.com_sample", "1.0.0.0", bean.AccessKey, bean.SecretKey, config);


            //-------------------------------
            // ���N�G�X�g�p�����[�^�̃Z�b�g
            //-------------------------------
            GetLowestOfferListingsForASINRequest request = new GetLowestOfferListingsForASINRequest();
            ASINListType asinList = new ASINListType();
            asinList.ASIN = new List<string>();
            string[] inputAsinCodes = asinCode.Split(new Char[] { ',' });
            for (int i = 0; i < inputAsinCodes.Length; i++)
            {
                asinList.ASIN.Add(inputAsinCodes[i]);
            }

            request.ASINList = asinList;
            request.SellerId = bean.AssociateTag;
            request.MarketplaceId = bean.MarketplaceId;
            request.ItemCondition = "New";
            //-------------------------------
            // MWS���N�G�X�gAPI�̎��s
            //-------------------------------
            GetLowestOfferListingsForASINResponse response = null;
            // try
            // {

            response = service.GetLowestOfferListingsForASIN(request);
            int ii = 0;
            List<GetLowestOfferListingsForASINResult> resultList = response.GetLowestOfferListingsForASINResult;
            foreach (GetLowestOfferListingsForASINResult getLowestOfferListingsForASINResult in resultList)
            {

                Hashtable ht = listResults[ii];
                ii++;
                Console.WriteLine("=============================================================================");
                if (getLowestOfferListingsForASINResult.IsSetstatus())
                {
                    Console.WriteLine("Status : {0}", getLowestOfferListingsForASINResult.status);
                }

                //----------------
                // ���i�̏��
                //----------------
                if (getLowestOfferListingsForASINResult.IsSetASIN())
                {
                    Console.WriteLine("ASIN  : {0}", getLowestOfferListingsForASINResult.ASIN);
                }

                if (getLowestOfferListingsForASINResult.IsSetProduct())
                {
                    Product product = getLowestOfferListingsForASINResult.Product;
                    /**
                    if (product.IsSetSalesRankings())
                    {
                        SalesRankList salesRankings = product.SalesRankings;
                        List<SalesRankType> salesRankList = salesRankings.SalesRank;
                        foreach (SalesRankType salesRank in salesRankList)
                        {
                            Console.WriteLine("                        SalesRank");
                            if (salesRank.IsSetProductCategoryId())
                            {
                                Console.WriteLine("�J�e�S��ID :{0}", salesRank.ProductCategoryId);
                            }
                            if (salesRank.IsSetRank())
                            {
                                Console.WriteLine("�����N :{0}", salesRank.Rank);
                            }
                        }
                    }
                    
                    Hashtable ht;
                    if (listResults.Count > 0)
                    {
                        ht = listResults[0];
                    }
                    else
                    {
                        ht = new Hashtable();
                        listResults.Add(ht);
                    }*/
                    if (product.IsSetLowestOfferListings())
                    {
                        LowestOfferListingList lowestOfferListings = product.LowestOfferListings;
                        List<LowestOfferListingType> lowestOfferListingList = lowestOfferListings.LowestOfferListing;
                        int iCount = 0;
                        Decimal lowPrice = 100000000;
                        Decimal heightPrice = 0;
                        //-----------------------------------------
                        // �擾�����S�o�i����\������܂ŌJ��Ԃ�
                        //-----------------------------------------
                        foreach (LowestOfferListingType lowestOfferListing in lowestOfferListingList)
                        {
                            Console.WriteLine("------------------------------------------------");

                            if (lowestOfferListing.IsSetQualifiers())
                            {
                                QualifiersType qualifiers = lowestOfferListing.Qualifiers;
                                /**
                                if (qualifiers.IsSetItemCondition())
                                {
                                    String condName = getConditionName(qualifiers.ItemCondition);
                                    String subCondName = "";
                                    if (qualifiers.IsSetItemSubcondition())
                                    {
                                        subCondName = getItemSubconditionName(qualifiers.ItemSubcondition);
                                    }
                                    Console.WriteLine("�R���f�B�V����   :{0} {1}", condName, subCondName);

                                }
                                */
                                //------------------
                                // ���i���
                                //------------------
                                if (lowestOfferListing.IsSetPrice())
                                {
                                    PriceType price1 = lowestOfferListing.Price;
                                    if (price1.IsSetLandedPrice())
                                    {
                                        Console.Write("���z             :" + getPriceName(price1.LandedPrice));
                                        //heightPrice = getPriceName(price1.ListingPrice);
                                        Decimal ip = 0;
                                        // ���z�̃Z�b�g
                                        if (price1.LandedPrice.IsSetAmount())
                                        {
                                            ip = price1.LandedPrice.Amount;
                                            //ip = int.Parse(pp);
                                        }
                                        if (lowPrice > ip)
                                        {
                                            lowPrice = ip;
                                            iCount = 0;
                                        }
                                        else
                                        {
                                            iCount = 1;
                                        }

                                        if (heightPrice < ip)
                                        {
                                            heightPrice = ip;

                                        }



                                    }
                                    // else
                                    //{
                                    //   heightPrice = price1.LandedPrice.Amount;
                                    //}

                                    // if (price1.IsSetShipping() && iCount == 0)
                                    //{
                                    //   Console.WriteLine("(����:" + getPriceName(price1.Shipping) + ")");
                                    //  ht[Const.GRIDVIEW_TITLE_SHIPPRICE] = price1.Shipping.Amount.ToString();
                                    // }
                                }
                                else
                                {
                                    lowPrice = 0;
                                    heightPrice = 0;
                                }
                                /**
                                                                if (qualifiers.IsSetFulfillmentChannel() && iCount == 0)
                                                                {
                                                                    Console.WriteLine("�o�׌�           :{0}", qualifiers.FulfillmentChannel);
                                                                    if (qualifiers.FulfillmentChannel.Equals(Const.AMAZON))
                                                                    {
                                                                        ht[Const.GRIDVIEW_TITLE_FBA] = "��";
                                                                    }
                                                                    else
                                                                    {
                                                                        ht[Const.GRIDVIEW_TITLE_FBA] = "";
                                                                    }
                                                                }
                                
                                                               if (qualifiers.IsSetShipsDomestically())
                                                               {
                                                                   Console.WriteLine("������蔭��     :{0}", qualifiers.ShipsDomestically);

                                                               }
                                                               if (qualifiers.IsSetShippingTime() && qualifiers.ShippingTime.IsSetMax())
                                                               {
                                                                   Console.WriteLine("��������(�ő�)   :{0}", qualifiers.ShippingTime.Max);
                                                               }
                                                               if (lowestOfferListing.IsSetSellerFeedbackCount())
                                                               {
                                                                   Console.Write("�t�B�[�h�o�b�N�� :{0}", lowestOfferListing.SellerFeedbackCount);
                                                                   if (qualifiers.IsSetSellerPositiveFeedbackRating())
                                                                   {
                                                                       Console.Write(" (���]��:{0})", qualifiers.SellerPositiveFeedbackRating);
                                                                   }
                                                                   Console.WriteLine("");
                                                               }
                                                               */

                            }
                            if (lowestOfferListing.IsSetNumberOfOfferListingsConsidered() && iCount == 0)
                            {
                                Console.WriteLine("�o�i��           :{0}", lowestOfferListing.NumberOfOfferListingsConsidered);
                                ht[Const.GRIDVIEW_TITLE_SUM] = lowestOfferListing.NumberOfOfferListingsConsidered;
                            }



                        }
                        if (lowPrice == 100000000)
                        {
                            ht[Const.GRIDVIEW_TITLE_PRICE] = "";
                        }
                        else
                        {
                            ht[Const.GRIDVIEW_TITLE_PRICE] = lowPrice.ToString();
                        }
                        // if (heightPrice == 0)
                        //{
                        //    ht[Const.GRIDVIEW_TITLE_HEIGHTPRICE] = "";
                        //}
                        //else
                        //{
                        //   ht[Const.GRIDVIEW_TITLE_HEIGHTPRICE] = heightPrice.ToString();
                        //}

                    }


                }

                if (getLowestOfferListingsForASINResult.IsSetError())
                {
                    Console.WriteLine("�G���[���������܂���");
                    Error error = getLowestOfferListingsForASINResult.Error;
                    if (error.IsSetType())
                    {
                        Console.WriteLine("Type: {0}", error.Type);
                    }
                    if (error.IsSetCode())
                    {
                        Console.WriteLine("Code: {0}", error.Code);
                    }
                    if (error.IsSetMessage())
                    {
                        Console.WriteLine("Message: {0}", error.Message);
                    }
                }

            }

            // }
            //  catch (MarketplaceWebServiceProductsException ex)
            //  {
            //      Console.WriteLine("Caught Exception: " + ex.Message);
            //     Console.WriteLine("Response Status Code: " + ex.StatusCode);
            //      Console.WriteLine("Error Code: " + ex.ErrorCode);
            //     Console.WriteLine("Error Type: " + ex.ErrorType);
            //      Console.WriteLine("Request ID: " + ex.RequestId);
            //     Console.WriteLine("XML: " + ex.XML);
            //      Console.WriteLine("ResponseHeaderMetadata: " + ex.ResponseHeaderMetadata);
            //  }

        }
        public void getResponse(string asinCode, List<Hashtable> listResults)
        {
            MarketplaceWebServiceProductsConfig config = new MarketplaceWebServiceProductsConfig();
            //bean.SiteURL = "https://mws.amazonservices.jp/Products/2011-10-01";
            //MarketplaceWebServiceProductsConfig config = new MarketplaceWebServiceProductsConfig();
            config.ServiceURL = bean.SiteURL + "/Products/2011-10-01";
            makeConfig(bean, config);
            //-------------------------------------
            // WebService���I�u�W�F�N�g���擾
            //-------------------------------------
            MarketplaceWebServiceProductsClient service = new MarketplaceWebServiceProductsClient(
                             "nanoappli.com_sample", "1.0.0.0", bean.AccessKey, bean.SecretKey, config);


            //-------------------------------
            // ���N�G�X�g�p�����[�^�̃Z�b�g
            //-------------------------------
            //GetLowestOfferListingsForASINRequest request = new GetLowestOfferListingsForASINRequest();
            MarketplaceWebServiceProducts.Model.GetMatchingProductRequest request = new MarketplaceWebServiceProducts.Model.GetMatchingProductRequest();
            MarketplaceWebServiceProducts.Model.ASINListType asinList = new MarketplaceWebServiceProducts.Model.ASINListType();
            asinList.ASIN = new List<string>();
            string[] inputAsinCodes = asinCode.Split(new Char[] { ',' });
            for (int i = 0; i < inputAsinCodes.Length; i++)
            {
                asinList.ASIN.Add(inputAsinCodes[i]);
            }
            //asinList.ASIN.Add("4478312141");
            //asinList.ASIN.Add("4797330058");

            request.ASINList = asinList;
            request.SellerId = bean.AssociateTag;
            request.MarketplaceId = bean.MarketplaceId;

            //-------------------------------
            // MWS���N�G�X�gAPI�̎��s
            //-------------------------------
            // GetLowestOfferListingsForASINResponse response = null;
            MarketplaceWebServiceProducts.Model.GetMatchingProductResponse response = null;
            // try
            // {
            //response = service.GetLowestOfferListingsForASIN(request);
            response = service.GetMatchingProduct(request);
            MarketplaceWebServiceProducts.Model.ResponseMetadata responseMetadata = response.ResponseMetadata;
            List<MarketplaceWebServiceProducts.Model.GetMatchingProductResult> resultList = response.GetMatchingProductResult;

            Hashtable ht;

            for (int i = 1; i < resultList.Count + 1; i++)
            //foreach (GetMatchingProductResult getMatchingProductResult in resultList)
            {
                ht = new Hashtable();

                //ht[Const.GRIDVIEW_TITLE_NO] = i.ToString();
                // datas[1] = resultList[i - 1].ASIN;      Hashtable  ht = new Hashtable();
                listResults.Add(ht);


                if (resultList[i - 1].IsSetProduct())
                {
                    MarketplaceWebServiceProducts.Model.Product product = resultList[i - 1].Product;
                    if (product.IsSetAttributeSets())
                    {
                        MarketplaceWebServiceProducts.Model.AttributeSetList attributeSets = product.AttributeSets;
                        if (attributeSets.IsSetAny())

                            foreach (Object attribute in attributeSets.Any)
                            {
                                string xml = MarketplaceWebServiceProducts.Model.ProductsUtil.FormatXml((System.Xml.XmlElement)attribute);
                                XElement element = XElement.Parse(xml);

                                XNamespace ns2 =
                                    "http://mws.amazonservices.com/schema/Products/2011-10-01/default.xsd";
                                XElement titleElement = element.Element(ns2 + "Title");
                                if (titleElement != null)
                                {
                                    ht[Const.GRIDVIEW_TITLE_TITLE] = titleElement.Value;
                                }
                                else
                                {
                                    ht[Const.GRIDVIEW_TITLE_TITLE] = "";
                                }
                                /**
                                XElement bindElement = element.Element(ns2 + "Binding");
                                if (bindElement != null)
                                {
                                    ht[Const.GRIDVIEW_CATEGORY] = bindElement.Value;
                                }
                                XElement productElement = element.Element(ns2 + "ProductGroup");
                                if (productElement != null && listResults[0][Const.GRIDVIEW_CATEGORY] == null)
                                {
                                    ht[Const.GRIDVIEW_CATEGORY] = productElement.Value;
                                }

                                
                                                                    // ���i�̐���
                                                                    string desplay = null;
                                                                    foreach (XElement feature in element.Elements(ns2 + "Feature"))
                                                                    {
                                                                        desplay += feature.Value;
                                                                        desplay += "\n";
                                                                    }
                                                                    listResults[0][Const.GRIDVIEW_TITLE_DESCRIPE] = desplay;

                                                                    XElement imageElement = element.Element(ns2 + "SmallImage");
                                                                    if (imageElement != null)
                                                                    {
                                                                        listResults[0][Const.GRIDVIEW_TITLE_IMAGEPATH] = imageElement.Element(ns2 + "URL").Value;
                                                                    }
                                                                    else
                                                                    {
                                                                        listResults[0][Const.GRIDVIEW_TITLE_IMAGEPATH] = "";
                                                                    }
                                                                    */
                                XElement packageDimensions = element.Element(ns2 + "PackageDimensions");
                                if (packageDimensions == null)
                                {
                                    packageDimensions = element.Element(ns2 + "ItemDimensions");
                                }
                                if (packageDimensions != null && packageDimensions.HasElements)
                                {
                                    double wig;
                                    double rate;
                                    if (packageDimensions.Element(ns2 + "Weight") != null)
                                    {
                                        string wight = packageDimensions.Element(ns2 + "Weight").Value;
                                        wig = double.Parse(wight);
                                        rate = 0.453592369999995;
                                        rate = ToHalfAdjust(wig * rate, 3);
                                        ht[Const.GRIDVIEW_TITLE_WEIGHT] = rate.ToString();
                                        DataTable dataTable = bean.ShppingDataTable;
                                        if (dataTable != null)
                                        {
                                            for (int ii = 0; ii < dataTable.Rows.Count; ii++)
                                            {
                                                DataRow row = dataTable.Rows[ii];
                                                if (ii == 0 && Convert.ToInt32(row[0]) >= rate * 1000)
                                                {
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EMS1] = row[1].ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EMS2] = row[2].ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EMS3] = row[3].ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EMS4] = row[4].ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EP1] = row[5].ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EP2] = row[6].ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EP3] = row[7].ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_SAL1] = row[8].ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_SAL2] = row[9].ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_SAL3] = row[10].ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_SAL1_1] = (Convert.ToInt32(row[8]) + 410).ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_SAL2_1] = (Convert.ToInt32(row[9]) + 410).ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_SAL3_1] = (Convert.ToInt32(row[10]) + 410).ToString();
                                                    break;
                                                }
                                                else if (ii + 1 < dataTable.Rows.Count && Convert.ToInt32(row[0]) < rate * 1000 && Convert.ToInt32(dataTable.Rows[ii + 1][0]) >= rate * 1000)
                                                {
                                                    row = dataTable.Rows[ii + 1];
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EMS1] = row[1].ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EMS2] = row[2].ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EMS3] = row[3].ToString();
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EMS4] = row[4].ToString();
                                                    if (rate * 1000 < 2000)
                                                    {
                                                        ht[Const.GRIDVIEW_SHIPPRICE_EP1] = row[5].ToString();
                                                        ht[Const.GRIDVIEW_SHIPPRICE_EP2] = row[6].ToString();
                                                        ht[Const.GRIDVIEW_SHIPPRICE_EP3] = row[7].ToString();
                                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL1] = row[8].ToString();
                                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL1_1] = (Convert.ToInt32(row[8]) + 410).ToString();
                                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL2] = row[9].ToString();
                                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL2_1] = (Convert.ToInt32(row[9]) + 410).ToString();
                                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL3] = row[10].ToString();
                                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL3_1] = (Convert.ToInt32(row[10]) + 410).ToString();
                                                    }
                                                    else
                                                    {
                                                        ht[Const.GRIDVIEW_SHIPPRICE_EP1] = "-";
                                                        ht[Const.GRIDVIEW_SHIPPRICE_EP2] = "-";
                                                        ht[Const.GRIDVIEW_SHIPPRICE_EP3] = "-";
                                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL1] = "-";
                                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL2] = "-";
                                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL3] = "-";
                                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL1_1] = "-";
                                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL2_1] = "-";
                                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL3_1] = "-";
                                                    }
                                                    break;
                                                }
                                                else if (ii + 1 >= dataTable.Rows.Count)
                                                {
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EMS1] = "-";
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EMS2] = "-";
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EMS3] = "-";
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EMS4] = "-";
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EP1] = "-";
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EP2] = "-";
                                                    ht[Const.GRIDVIEW_SHIPPRICE_EP3] = "-";
                                                    ht[Const.GRIDVIEW_SHIPPRICE_SAL1] = "-";
                                                    ht[Const.GRIDVIEW_SHIPPRICE_SAL2] = "-";
                                                    ht[Const.GRIDVIEW_SHIPPRICE_SAL3] = "-";
                                                    ht[Const.GRIDVIEW_SHIPPRICE_SAL1_1] = "-";
                                                    ht[Const.GRIDVIEW_SHIPPRICE_SAL2_1] = "-";
                                                    ht[Const.GRIDVIEW_SHIPPRICE_SAL3_1] = "-";
                                                }
                                            }
                                        }
                                        else
                                        {
                                            ht[Const.GRIDVIEW_SHIPPRICE_EMS1] = "-";
                                            ht[Const.GRIDVIEW_SHIPPRICE_EMS2] = "-";
                                            ht[Const.GRIDVIEW_SHIPPRICE_EMS3] = "-";
                                            ht[Const.GRIDVIEW_SHIPPRICE_EMS4] = "-";
                                            ht[Const.GRIDVIEW_SHIPPRICE_EP1] = "-";
                                            ht[Const.GRIDVIEW_SHIPPRICE_EP2] = "-";
                                            ht[Const.GRIDVIEW_SHIPPRICE_EP3] = "-";
                                            ht[Const.GRIDVIEW_SHIPPRICE_SAL1] = "-";
                                            ht[Const.GRIDVIEW_SHIPPRICE_SAL2] = "-";
                                            ht[Const.GRIDVIEW_SHIPPRICE_SAL3] = "-";
                                            ht[Const.GRIDVIEW_SHIPPRICE_SAL1_1] = "-";
                                            ht[Const.GRIDVIEW_SHIPPRICE_SAL2_1] = "-";
                                            ht[Const.GRIDVIEW_SHIPPRICE_SAL3_1] = "-";
                                        }
                                    }
                                    else
                                    {
                                        ht[Const.GRIDVIEW_TITLE_WEIGHT] = "-";
                                        ht[Const.GRIDVIEW_SHIPPRICE_EMS1] = "-";
                                        ht[Const.GRIDVIEW_SHIPPRICE_EMS2] = "-";
                                        ht[Const.GRIDVIEW_SHIPPRICE_EMS3] = "-";
                                        ht[Const.GRIDVIEW_SHIPPRICE_EMS4] = "-";
                                        ht[Const.GRIDVIEW_SHIPPRICE_EP1] = "-";
                                        ht[Const.GRIDVIEW_SHIPPRICE_EP2] = "-";
                                        ht[Const.GRIDVIEW_SHIPPRICE_EP3] = "-";
                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL1] = "-";
                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL2] = "-";
                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL3] = "-";
                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL1_1] = "-";
                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL2_1] = "-";
                                        ht[Const.GRIDVIEW_SHIPPRICE_SAL3_1] = "-";
                                    }
                                    string height = null;
                                    string width = null;
                                    string length = null;
                                    if (packageDimensions.Element(ns2 + "Height") != null)
                                    {
                                        height = packageDimensions.Element(ns2 + "Height").Value;
                                    }
                                    if (packageDimensions.Element(ns2 + "Length") != null)
                                    {
                                        length = packageDimensions.Element(ns2 + "Length").Value;
                                    }
                                    if (packageDimensions.Element(ns2 + "Width") != null)
                                    {
                                        width = packageDimensions.Element(ns2 + "Width").Value;
                                    }
                                    // packageDimensions.Element(ns2 + "Width").Value;
                                    if (height != null && height.Length > 0)
                                    {
                                        if (width != null && width.Length > 0)
                                        {
                                            if (length != null && length.Length > 0)
                                            {
                                                rate = 2.54;
                                                wig = double.Parse(height);
                                                double iHeight = ToHalfAdjust(wig * rate / 100, 1);
                                                wig = double.Parse(width);
                                                double iWidth = ToHalfAdjust(wig * rate / 100, 1);
                                                wig = double.Parse(length);
                                                double iLength = ToHalfAdjust(wig * rate / 100, 1);
                                                ht[Const.GRIDVIEW_TITLE_SIZE] = string.Format("��{0}�~���s{1}�~����{2}cm", iWidth, iHeight, iLength);
                                            }
                                            else
                                            {
                                                rate = 2.54;
                                                wig = double.Parse(height);
                                                double iHeight = ToHalfAdjust(wig * rate / 100, 1);
                                                wig = double.Parse(width);
                                                double iWidth = ToHalfAdjust(wig * rate / 100, 1);
                                                ht[Const.GRIDVIEW_TITLE_SIZE] = string.Format("��{0}�~���s{1}cm", iWidth, iHeight);
                                            }
                                        }
                                        else
                                        {
                                            if (length != null && length.Length > 0)
                                            {
                                                rate = 2.54;
                                                wig = double.Parse(height);
                                                double iHeight = ToHalfAdjust(wig * rate / 100, 1);
                                                wig = double.Parse(length);
                                                double iLength = ToHalfAdjust(wig * rate / 100, 1);
                                                ht[Const.GRIDVIEW_TITLE_SIZE] = string.Format("���s{1}�~����{2}cm", iHeight, iLength);
                                            }
                                            else
                                            {
                                                rate = 2.54;
                                                wig = double.Parse(height);
                                                double iHeight = ToHalfAdjust(wig * rate / 100, 1);
                                                ht[Const.GRIDVIEW_TITLE_SIZE] = string.Format("���s{1}cm", iHeight);
                                            }
                                        }
                                    }
                                    else
                                    {

                                        if (width != null && width.Length > 0)
                                        {
                                            if (length != null && length.Length > 0)
                                            {
                                                rate = 2.54;
                                                wig = double.Parse(width);
                                                double iWidth = ToHalfAdjust(wig * rate / 100, 1);
                                                wig = double.Parse(length);
                                                double iLength = ToHalfAdjust(wig * rate / 100, 1);
                                                ht[Const.GRIDVIEW_TITLE_SIZE] = string.Format("��{0}�~����{2}cm", iWidth, iLength);
                                            }
                                            else
                                            {
                                                rate = 2.54;
                                                wig = double.Parse(width);
                                                double iWidth = ToHalfAdjust(wig * rate / 100, 1);
                                                ht[Const.GRIDVIEW_TITLE_SIZE] = string.Format("��{0}cm", iWidth);
                                            }
                                        }
                                        else
                                        {
                                            if (length != null && length.Length > 0)
                                            {
                                                rate = 2.54;
                                                wig = double.Parse(length);
                                                double iLength = ToHalfAdjust(wig * rate / 100, 1);
                                                ht[Const.GRIDVIEW_TITLE_SIZE] = string.Format("����{2}cm", iLength);
                                            }
                                            else
                                            {

                                                ht[Const.GRIDVIEW_TITLE_SIZE] = "";
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    ht[Const.GRIDVIEW_TITLE_WEIGHT] = "";
                                    ht[Const.GRIDVIEW_TITLE_SIZE] = "";
                                }
                                //string height = element.Element(ns2 + "ItemDimensions").Element(ns2 + "Height").Value;
                                // string length = element.Element(ns2 + "ItemDimensions").Element(ns2 + "Length").Value;
                                //string width = element.Element(ns2 + "ItemDimensions").Element(ns2 + "Width").Value;
                                // string weight = element.Element(ns2 + "ItemDimensions").Element(ns2 + "Weight").Value;

                            }
                    }

                    if (product.IsSetIdentifiers())
                    {
                        MarketplaceWebServiceProducts.Model.IdentifierType identifier = product.Identifiers;
                        if (identifier.IsSetMarketplaceASIN())
                        {
                            MarketplaceWebServiceProducts.Model.ASINIdentifier marketplaceASIN = identifier.MarketplaceASIN;
                            if (marketplaceASIN.IsSetASIN())
                            {
                                ht[Const.GRIDVIEW_TITLE_ASIN] = marketplaceASIN.ASIN;
                            }
                        }
                    }
                    /**
                                        if (product.IsSetSalesRankings())
                                        {
                                            int j = 0;
                                            MarketplaceWebServiceProducts.Model.SalesRankList rankings = product.SalesRankings;
                                            List<MarketplaceWebServiceProducts.Model.SalesRankType> salesRankList = rankings.SalesRank;
                                            foreach (MarketplaceWebServiceProducts.Model.SalesRankType saleRankings in salesRankList)
                                            {
                                                for (; j < 1; j++)
                                                {
                                                    if (saleRankings.IsSetRank())
                                                    {
                                                        string salesRank = Convert.ToString(saleRankings.Rank);
                                                    }
                                                }
                                            }
                                        }
                     */
                }


            }
            /**
        }
        catch (MarketplaceWebServiceProductsException ex)
        {
            Console.WriteLine("Caught Exception: " + ex.Message);
            Console.WriteLine("Response Status Code: " + ex.StatusCode);
            Console.WriteLine("Error Code: " + ex.ErrorCode);
            Console.WriteLine("Error Type: " + ex.ErrorType);
            Console.WriteLine("Request ID: " + ex.RequestId);
            Console.WriteLine("XML: " + ex.XML);
            Console.WriteLine("ResponseHeaderMetadata: " + ex.ResponseHeaderMetadata);
        }
*/
        }
        //****************************************************************************
        // Function     : showResponse
        // Description  : Web�T�[�r�X���s���ʂ̕\��
        // Params       : response WebAPI���s����
        //****************************************************************************
        public static void showResponse(GetLowestOfferListingsForASINResponse response, DataGridView dataGridView1)
        {

            List<MarketplaceWebServiceProducts.Model.GetLowestOfferListingsForASINResult> resultList = response.GetLowestOfferListingsForASINResult;
            // dataGridView1.Rows.Add(
            foreach (MarketplaceWebServiceProducts.Model.GetLowestOfferListingsForASINResult getLowestOfferListingsForASINResult in resultList)
            {
                string[] data = new string[3];
                Console.WriteLine("=============================================================================");
                if (getLowestOfferListingsForASINResult.IsSetstatus())
                {
                    Console.WriteLine("Status : {0}", getLowestOfferListingsForASINResult.status);
                }

                //----------------
                // ���i�̏��
                //----------------
                if (getLowestOfferListingsForASINResult.IsSetASIN())
                {
                    Console.WriteLine("ASIN  : {0}", getLowestOfferListingsForASINResult.ASIN);
                }

                if (getLowestOfferListingsForASINResult.IsSetProduct())
                {
                    MarketplaceWebServiceProducts.Model.Product product = getLowestOfferListingsForASINResult.Product;

                    if (product.IsSetSalesRankings())
                    {
                        MarketplaceWebServiceProducts.Model.SalesRankList salesRankings = product.SalesRankings;
                        List<MarketplaceWebServiceProducts.Model.SalesRankType> salesRankList = salesRankings.SalesRank;
                        foreach (MarketplaceWebServiceProducts.Model.SalesRankType salesRank in salesRankList)
                        {
                            Console.WriteLine("                        SalesRank");
                            if (salesRank.IsSetProductCategoryId())
                            {
                                Console.WriteLine("�J�e�S��ID :{0}", salesRank.ProductCategoryId);
                            }
                            if (salesRank.IsSetRank())
                            {
                                Console.WriteLine("�����N :{0}", salesRank.Rank);
                            }
                        }
                    }


                    if (product.IsSetLowestOfferListings())
                    {
                        MarketplaceWebServiceProducts.Model.LowestOfferListingList lowestOfferListings = product.LowestOfferListings;
                        List<MarketplaceWebServiceProducts.Model.LowestOfferListingType> lowestOfferListingList = lowestOfferListings.LowestOfferListing;

                        //-----------------------------------------
                        // �擾�����S�o�i����\������܂ŌJ��Ԃ�
                        //-----------------------------------------
                        foreach (MarketplaceWebServiceProducts.Model.LowestOfferListingType lowestOfferListing in lowestOfferListingList)
                        {
                            Console.WriteLine("------------------------------------------------");

                            if (lowestOfferListing.IsSetQualifiers())
                            {
                                MarketplaceWebServiceProducts.Model.QualifiersType qualifiers = lowestOfferListing.Qualifiers;
                                if (qualifiers.IsSetItemCondition())
                                {
                                    String condName = getConditionName(qualifiers.ItemCondition);
                                    String subCondName = "";
                                    if (qualifiers.IsSetItemSubcondition())
                                    {
                                        subCondName = getItemSubconditionName(qualifiers.ItemSubcondition);
                                    }
                                    Console.WriteLine("�R���f�B�V����   :{0} {1}", condName, subCondName);

                                }

                                if (qualifiers.IsSetFulfillmentChannel())
                                {
                                    Console.WriteLine("�o�׌�           :{0}", qualifiers.FulfillmentChannel);
                                }
                                if (qualifiers.IsSetShipsDomestically())
                                {
                                    Console.WriteLine("������蔭��     :{0}", qualifiers.ShipsDomestically);
                                }
                                if (qualifiers.IsSetShippingTime() && qualifiers.ShippingTime.IsSetMax())
                                {
                                    Console.WriteLine("��������(�ő�)   :{0}", qualifiers.ShippingTime.Max);
                                }
                                if (lowestOfferListing.IsSetSellerFeedbackCount())
                                {
                                    Console.Write("�t�B�[�h�o�b�N�� :{0}", lowestOfferListing.SellerFeedbackCount);
                                    if (qualifiers.IsSetSellerPositiveFeedbackRating())
                                    {
                                        Console.Write(" (���]��:{0})", qualifiers.SellerPositiveFeedbackRating);
                                    }
                                    Console.WriteLine("");
                                }


                            }
                            if (lowestOfferListing.IsSetNumberOfOfferListingsConsidered())
                            {
                                Console.WriteLine("�o�i��           :{0}", lowestOfferListing.NumberOfOfferListingsConsidered);
                            }

                            //------------------
                            // ���i���
                            //------------------
                            if (lowestOfferListing.IsSetPrice())
                            {
                                MarketplaceWebServiceProducts.Model.PriceType price1 = lowestOfferListing.Price;
                                if (price1.IsSetLandedPrice())
                                {
                                    Console.Write("���z             :" + getPriceName(price1.LandedPrice));
                                }

                                if (price1.IsSetShipping())
                                {
                                    Console.WriteLine("(����:" + getPriceName(price1.Shipping) + ")");
                                }
                            }
                        }
                    }


                }

                if (getLowestOfferListingsForASINResult.IsSetError())
                {
                    Console.WriteLine("�G���[���������܂���");
                    MarketplaceWebServiceProducts.Model.Error error = getLowestOfferListingsForASINResult.Error;
                    if (error.IsSetType())
                    {
                        Console.WriteLine("Type: {0}", error.Type);
                    }
                    if (error.IsSetCode())
                    {
                        Console.WriteLine("Code: {0}", error.Code);
                    }
                    if (error.IsSetMessage())
                    {
                        Console.WriteLine("Message: {0}", error.Message);
                    }
                }
            }

        }


        //****************************************************************************
        // Function     : getConditionName
        // Description  : �R���f�B�V������(���{��)���擾����
        //****************************************************************************
        private static string getConditionName(string inStr)
        {
            switch (inStr)
            {
                case "New":
                    return "�V�i";
                case "Used":
                    return "���Õi";
                case "Collectible":
                    return "�R���N�^�[�i";
                case "Refurbished":
                    return "�Đ��i";
                default:
                    return inStr;
            }
        }

        //****************************************************************************
        // Function     : getItemSubconditionName
        // Description  : �T�u�R���f�B�V������(���{��)���擾����
        //****************************************************************************
        private static string getItemSubconditionName(string inStr)
        {
            switch (inStr)
            {
                case "New":
                    return "�V�i";
                case "Mint":
                    return "�قڐV�i";
                case "Very Good":
                case "VeryGood":
                    return "���ɗǂ�";
                case "Good":
                    return "�ǂ�";
                default:
                    return inStr;
            }
        }

        //****************************************************************************
        // Function     : getFulfillmentChannelName
        // Description  : �o�׌�(���{��)���擾����
        //****************************************************************************
        private static string getFulfillmentChannelName(string inStr)
        {
            switch (inStr)
            {
                case "Amazon":
                    return "FBA";
                case "Merchant":
                    return "�o�i��";
                default:
                    return inStr;
            }
        }
        public static double ToHalfAdjust(double dValue, int iDigits)
        {
            double dCoef = System.Math.Pow(10, iDigits);

            return dValue > 0 ? System.Math.Floor((dValue * dCoef) + 0.5) / dCoef :
                                System.Math.Ceiling((dValue * dCoef) - 0.5) / dCoef;
        }

        private static void makeConfig(PropertiesBean bean, MarketplaceWebServiceProductsConfig config)
        {
            if (bean.ProxyServer != null && bean.ProxyServer.Length > 0)
            {
                config.ProxyHost = "158.213.151.4";
                config.ProxyPort = 8080;
                //config.ProxyPort = bean.
                config.ProxyUsername = bean.ProxyUser;
                config.ProxyPassword = bean.ProxyPwd;
            }
        }
        //****************************************************************************
        // Function     : getPriceName
        // Description  : ���i(�ʉݒP�ʕt��)���擾����
        //****************************************************************************
        private static string getPriceName(MarketplaceWebServiceProducts.Model.MoneyType inData)
        {
            string outStr = "";

            // �ʉݒP�ʂ̃Z�b�g
            if (inData.IsSetCurrencyCode())
            {
                switch (inData.CurrencyCode)
                {
                    case "JPY":
                        outStr += "\\";
                        break;
                    case "USD":
                        outStr += "$";
                        break;
                    default:
                        outStr += "(" + inData.CurrencyCode + ")";
                        break;
                }
            }

            // ���z�̃Z�b�g
            if (inData.IsSetAmount())
            {
                outStr += String.Format("{0:0}", inData.Amount);
            }

            return outStr;
        }
    }
}
