using System;
using System.Collections.Generic;
using System.Text;

namespace amazonTool.requests
{
    class Const
    {
        public  const string GRIDVIEW_TITLE_NO = "No";
        public  const string GRIDVIEW_TITLE_ASIN = "Asin";
        public  const string GRIDVIEW_TITLE_TITLE = "Title";
        public  const string GRIDVIEW_TITLE_PRICE = "Price";
        public const string GRIDVIEW_TITLE_SHIPPRICE = "ShippingPrice";
        public const string GRIDVIEW_TITLE_HEIGHTPRICE = "HeightPrice";
        public  const string GRIDVIEW_TITLE_SUM = "Sum";
        public  const string GRIDVIEW_TITLE_IMAGEPATH = "ImagePath";
        public  const string GRIDVIEW_TITLE_DESCRIPE = "Descripe";
        public  const string GRIDVIEW_TITLE_WEIGHT = "Weight";
        public const string GRIDVIEW_TITLE_FBA = "FBS";
        public const string AMAZON = "Amazon";
        public const string GRIDVIEW_TITLE_SIZE = "Size";
        public const string GRIDVIEW_BRAND = "Brand";
        public const string GRIDVIEW_GROUP_NAME = "ProductGroup";
        public const string GRIDVIEW_TYPE_NAME = "ProductTypeName";
        public const string GRIDVIEW_Manufacturer = "Manufacturer";

        public const string GRIDVIEW_SHIPPRICE_EMS1 = "ems1";
        public const string GRIDVIEW_SHIPPRICE_EMS2 = "ems2";
        public const string GRIDVIEW_SHIPPRICE_EMS3 = "ems3";
        public const string GRIDVIEW_SHIPPRICE_EMS4 = "ems4";
        public const string GRIDVIEW_SHIPPRICE_EP1 = "ep1";
        public const string GRIDVIEW_SHIPPRICE_EP2 = "ep2";
        public const string GRIDVIEW_SHIPPRICE_EP3 = "ep3";
        public const string GRIDVIEW_SHIPPRICE_SAL1 = "sal1";
        public const string GRIDVIEW_SHIPPRICE_SAL1_1 = "sal1_1";
        public const string GRIDVIEW_SHIPPRICE_SAL2 = "sal2";
        public const string GRIDVIEW_SHIPPRICE_SAL2_1 = "sal2_1";
        public const string GRIDVIEW_SHIPPRICE_SAL3 = "sal3";
        public const string GRIDVIEW_SHIPPRICE_SAL3_1 = "sal3_1";
    }
}
