﻿namespace amazonTool
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.selectBnt = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.search2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.searchByAsin = new System.Windows.Forms.Button();
            this.asinCodeTextBox = new System.Windows.Forms.TextBox();
            this.search1 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar1 = new System.Windows.Forms.ToolStripProgressBar();
            this.label5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.outputText = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.sellText = new System.Windows.Forms.TextBox();
            this.secretText = new System.Windows.Forms.TextBox();
            this.accessText = new System.Windows.Forms.TextBox();
            this.set3 = new System.Windows.Forms.Label();
            this.set2 = new System.Windows.Forms.Label();
            this.set1 = new System.Windows.Forms.Label();
            this.num = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.asin = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.group = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.title = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brand = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maker = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.detail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.losestPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Shipping1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // selectBnt
            // 
            this.selectBnt.Location = new System.Drawing.Point(425, 51);
            this.selectBnt.Name = "selectBnt";
            this.selectBnt.Size = new System.Drawing.Size(75, 23);
            this.selectBnt.TabIndex = 0;
            this.selectBnt.Text = "選択";
            this.selectBnt.UseVisualStyleBackColor = true;
            this.selectBnt.Click += new System.EventHandler(this.selectBnt_Click);
            // 
            // textBox1
            // 
            this.textBox1.AcceptsTab = true;
            this.textBox1.AllowDrop = true;
            this.textBox1.Location = new System.Drawing.Point(111, 53);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(290, 19);
            this.textBox1.TabIndex = 1;
            // 
            // search2
            // 
            this.search2.AutoSize = true;
            this.search2.Location = new System.Drawing.Point(30, 54);
            this.search2.Name = "search2";
            this.search2.Size = new System.Drawing.Size(68, 12);
            this.search2.TabIndex = 2;
            this.search2.Text = "CSVファイル：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.selectBnt);
            this.groupBox1.Controls.Add(this.search2);
            this.groupBox1.Controls.Add(this.searchByAsin);
            this.groupBox1.Controls.Add(this.asinCodeTextBox);
            this.groupBox1.Controls.Add(this.search1);
            this.groupBox1.Location = new System.Drawing.Point(16, 140);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(814, 140);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "検索";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(274, 105);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(116, 16);
            this.radioButton2.TabIndex = 7;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "推奨商品のみ検索";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(111, 106);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(135, 16);
            this.radioButton1.TabIndex = 6;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "全ての重複商品を検索";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 109);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "オプション：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "カテゴリ：";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(111, 78);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 20);
            this.comboBox1.TabIndex = 3;
            // 
            // searchByAsin
            // 
            this.searchByAsin.Location = new System.Drawing.Point(696, 109);
            this.searchByAsin.Name = "searchByAsin";
            this.searchByAsin.Size = new System.Drawing.Size(101, 24);
            this.searchByAsin.TabIndex = 2;
            this.searchByAsin.Text = "検索";
            this.searchByAsin.UseVisualStyleBackColor = true;
            this.searchByAsin.Click += new System.EventHandler(this.searchByAsin_Click);
            // 
            // asinCodeTextBox
            // 
            this.asinCodeTextBox.Location = new System.Drawing.Point(111, 21);
            this.asinCodeTextBox.Name = "asinCodeTextBox";
            this.asinCodeTextBox.Size = new System.Drawing.Size(279, 19);
            this.asinCodeTextBox.TabIndex = 1;
            this.asinCodeTextBox.TextChanged += new System.EventHandler(this.asinCodeTextBox_TextChanged);
            // 
            // search1
            // 
            this.search1.AutoSize = true;
            this.search1.Location = new System.Drawing.Point(30, 21);
            this.search1.Name = "search1";
            this.search1.Size = new System.Drawing.Size(59, 12);
            this.search1.TabIndex = 0;
            this.search1.Text = "キーワード：";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dataGridView1);
            this.groupBox4.Location = new System.Drawing.Point(3, 286);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(839, 296);
            this.groupBox4.TabIndex = 6;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "検索結果";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.num,
            this.asin,
            this.group,
            this.type,
            this.title,
            this.brand,
            this.maker,
            this.detail,
            this.losestPrice,
            this.Shipping1});
            this.dataGridView1.Location = new System.Drawing.Point(9, 18);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = 21;
            this.dataGridView1.Size = new System.Drawing.Size(825, 271);
            this.dataGridView1.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripProgressBar1,
            this.label5});
            this.statusStrip1.Location = new System.Drawing.Point(0, 583);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(846, 23);
            this.statusStrip1.TabIndex = 9;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(68, 18);
            this.toolStripStatusLabel1.Text = "コマンド：";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(0, 18);
            // 
            // toolStripProgressBar1
            // 
            this.toolStripProgressBar1.Name = "toolStripProgressBar1";
            this.toolStripProgressBar1.Size = new System.Drawing.Size(100, 17);
            // 
            // label5
            // 
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 18);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.outputText);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.sellText);
            this.groupBox2.Controls.Add(this.secretText);
            this.groupBox2.Controls.Add(this.accessText);
            this.groupBox2.Controls.Add(this.set3);
            this.groupBox2.Controls.Add(this.set2);
            this.groupBox2.Controls.Add(this.set1);
            this.groupBox2.Location = new System.Drawing.Point(17, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(813, 131);
            this.groupBox2.TabIndex = 10;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "設定";
            // 
            // outputText
            // 
            this.outputText.Location = new System.Drawing.Point(128, 97);
            this.outputText.Name = "outputText";
            this.outputText.ReadOnly = true;
            this.outputText.Size = new System.Drawing.Size(335, 19);
            this.outputText.TabIndex = 16;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(490, 93);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(102, 23);
            this.button3.TabIndex = 15;
            this.button3.Text = "出力先の選択";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "出力先パス：";
            // 
            // sellText
            // 
            this.sellText.Location = new System.Drawing.Point(128, 72);
            this.sellText.Name = "sellText";
            this.sellText.Size = new System.Drawing.Size(245, 19);
            this.sellText.TabIndex = 1;
            this.sellText.TextChanged += new System.EventHandler(this.sellText_TextChanged);
            // 
            // secretText
            // 
            this.secretText.Location = new System.Drawing.Point(128, 46);
            this.secretText.Name = "secretText";
            this.secretText.Size = new System.Drawing.Size(245, 19);
            this.secretText.TabIndex = 1;
            this.secretText.TextChanged += new System.EventHandler(this.secretText_TextChanged);
            // 
            // accessText
            // 
            this.accessText.Location = new System.Drawing.Point(128, 21);
            this.accessText.Name = "accessText";
            this.accessText.Size = new System.Drawing.Size(245, 19);
            this.accessText.TabIndex = 1;
            this.accessText.TextChanged += new System.EventHandler(this.accessText_TextChanged);
            // 
            // set3
            // 
            this.set3.AutoSize = true;
            this.set3.Location = new System.Drawing.Point(11, 75);
            this.set3.Name = "set3";
            this.set3.Size = new System.Drawing.Size(51, 12);
            this.set3.TabIndex = 0;
            this.set3.Text = "Seller ID:";
            // 
            // set2
            // 
            this.set2.AutoSize = true;
            this.set2.Location = new System.Drawing.Point(11, 49);
            this.set2.Name = "set2";
            this.set2.Size = new System.Drawing.Size(63, 12);
            this.set2.TabIndex = 0;
            this.set2.Text = "Secret Key:";
            // 
            // set1
            // 
            this.set1.AutoSize = true;
            this.set1.Location = new System.Drawing.Point(8, 24);
            this.set1.Name = "set1";
            this.set1.Size = new System.Drawing.Size(83, 12);
            this.set1.TabIndex = 0;
            this.set1.Text = "Access Key ID:";
            // 
            // num
            // 
            this.num.HeaderText = "NO.";
            this.num.Name = "num";
            this.num.ReadOnly = true;
            this.num.Width = 50;
            // 
            // asin
            // 
            this.asin.HeaderText = "ASIN";
            this.asin.Name = "asin";
            this.asin.ReadOnly = true;
            // 
            // group
            // 
            this.group.HeaderText = "商品グループ";
            this.group.Name = "group";
            this.group.ReadOnly = true;
            this.group.Width = 80;
            // 
            // type
            // 
            this.type.HeaderText = "商品タイプ";
            this.type.Name = "type";
            this.type.ReadOnly = true;
            this.type.Width = 120;
            // 
            // title
            // 
            this.title.HeaderText = "商品名";
            this.title.Name = "title";
            this.title.ReadOnly = true;
            this.title.Width = 170;
            // 
            // brand
            // 
            this.brand.HeaderText = "ブランド名";
            this.brand.Name = "brand";
            this.brand.ReadOnly = true;
            this.brand.Width = 120;
            // 
            // maker
            // 
            this.maker.HeaderText = "メーカー名";
            this.maker.Name = "maker";
            this.maker.Width = 80;
            // 
            // detail
            // 
            this.detail.HeaderText = "商品の情報";
            this.detail.Name = "detail";
            this.detail.ReadOnly = true;
            this.detail.Visible = false;
            // 
            // losestPrice
            // 
            this.losestPrice.HeaderText = "最低価格";
            this.losestPrice.Name = "losestPrice";
            this.losestPrice.ReadOnly = true;
            // 
            // Shipping1
            // 
            this.Shipping1.HeaderText = "最低価格（配送料）";
            this.Shipping1.Name = "Shipping1";
            this.Shipping1.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(846, 606);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Amazonツール";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button selectBnt;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label search2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button searchByAsin;
        private System.Windows.Forms.TextBox asinCodeTextBox;
        private System.Windows.Forms.Label search1;
        private System.Windows.Forms.GroupBox groupBox4;
        //private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox sellText;
        private System.Windows.Forms.TextBox secretText;
        private System.Windows.Forms.TextBox accessText;
        private System.Windows.Forms.Label set3;
        private System.Windows.Forms.Label set2;
        private System.Windows.Forms.Label set1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolStripStatusLabel label5;
        private System.Windows.Forms.TextBox outputText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn num;
        private System.Windows.Forms.DataGridViewTextBoxColumn asin;
        private System.Windows.Forms.DataGridViewTextBoxColumn group;
        private System.Windows.Forms.DataGridViewTextBoxColumn type;
        private System.Windows.Forms.DataGridViewTextBoxColumn title;
        private System.Windows.Forms.DataGridViewTextBoxColumn brand;
        private System.Windows.Forms.DataGridViewTextBoxColumn maker;
        private System.Windows.Forms.DataGridViewTextBoxColumn detail;
        private System.Windows.Forms.DataGridViewTextBoxColumn losestPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Shipping1;
    }
}

