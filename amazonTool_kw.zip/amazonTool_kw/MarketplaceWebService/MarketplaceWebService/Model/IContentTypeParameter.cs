﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MarketplaceWebService.Model
{
    public interface IContentTypeParameter
    {
    }
}
